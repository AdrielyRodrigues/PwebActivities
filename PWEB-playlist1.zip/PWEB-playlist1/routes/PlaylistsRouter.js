import express from 'express';
import { Playlist } from '../models/index.js';

const router = express.Router();

// GET /playlists
router.get('/', async (req, res) => {
  const playlists = await Playlist.findAll();
  res.json(playlists);
});

// GET /playlists/:id
router.get('/:id', async (req, res) => {
  const playlist = await Playlist.findByPk(req.params.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist não encontrada' });
  res.json(playlist);
});

// POST /playlists
router.post('/', async (req, res) => {
  try {
    const novaPlaylist = await Playlist.create(req.body);
    res.status(201).json(novaPlaylist);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /playlists/:id
router.put('/:id', async (req, res) => {
  const playlist = await Playlist.findByPk(req.params.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist não encontrada' });

  await playlist.update(req.body);
  res.json(playlist);
});

// DELETE /playlists/:id
router.delete('/:id', async (req, res) => {
  const playlist = await Playlist.findByPk(req.params.id);
  if (!playlist) return res.status(404).json({ error: 'Playlist não encontrada' });

  await playlist.destroy();
  res.status(204).end();
});

export default router;
