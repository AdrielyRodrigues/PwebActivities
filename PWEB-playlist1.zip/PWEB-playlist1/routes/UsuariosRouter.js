import express from 'express';
import { Usuario } from '../models/index.js';

const router = express.Router();

// GET /usuarios
router.get('/', async (req, res) => {
  const usuarios = await Usuario.findAll();
  res.json(usuarios);
});

// GET /usuarios/:id
router.get('/:id', async (req, res) => {
  const usuario = await Usuario.findByPk(req.params.id);
  if (!usuario) return res.status(404).json({ error: 'Usuário não encontrado' });
  res.json(usuario);
});

// POST /usuarios
router.post('/', async (req, res) => {
  try {
    const novoUsuario = await Usuario.create(req.body);
    res.status(201).json(novoUsuario);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /usuarios/:id
router.put('/:id', async (req, res) => {
  const usuario = await Usuario.findByPk(req.params.id);
  if (!usuario) return res.status(404).json({ error: 'Usuário não encontrado' });

  await usuario.update(req.body);
  res.json(usuario);
});

// DELETE /usuarios/:id
router.delete('/:id', async (req, res) => {
  const usuario = await Usuario.findByPk(req.params.id);
  if (!usuario) return res.status(404).json({ error: 'Usuário não encontrado' });

  await usuario.destroy();
  res.status(204).end();
});

export default router;
