import express from 'express';
import { Filme } from '../models/index.js';

const router = express.Router();

// GET /filmes
router.get('/', async (req, res) => {
  const filmes = await Filme.findAll();
  res.json(filmes);
});

// GET /filmes/:id
router.get('/:id', async (req, res) => {
  const filme = await Filme.findByPk(req.params.id);
  if (!filme) return res.status(404).json({ error: 'Filme não encontrado' });
  res.json(filme);
});

// POST /filmes
router.post('/', async (req, res) => {
  try {
    const novoFilme = await Filme.create(req.body);
    res.status(201).json(novoFilme);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /filmes/:id
router.put('/:id', async (req, res) => {
  const filme = await Filme.findByPk(req.params.id);
  if (!filme) return res.status(404).json({ error: 'Filme não encontrado' });

  await filme.update(req.body);
  res.json(filme);
});

// DELETE /filmes/:id
router.delete('/:id', async (req, res) => {
  const filme = await Filme.findByPk(req.params.id);
  if (!filme) return res.status(404).json({ error: 'Filme não encontrado' });

  await filme.destroy();
  res.status(204).end();
});

export default router;
