import express from 'express';
import { Canal } from '../models/index.js';

const router = express.Router();

// GET /canais
router.get('/', async (req, res) => {
  const canais = await Canal.findAll();
  res.json(canais);
});

// GET /canais/:id
router.get('/:id', async (req, res) => {
  const canal = await Canal.findByPk(req.params.id);
  if (!canal) return res.status(404).json({ error: 'Canal não encontrado' });
  res.json(canal);
});

// POST /canais
router.post('/', async (req, res) => {
  try {
    const novoCanal = await Canal.create(req.body);
    res.status(201).json(novoCanal);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /canais/:id
router.put('/:id', async (req, res) => {
  const canal = await Canal.findByPk(req.params.id);
  if (!canal) return res.status(404).json({ error: 'Canal não encontrado' });

  await canal.update(req.body);
  res.json(canal);
});

// DELETE /canais/:id
router.delete('/:id', async (req, res) => {
  const canal = await Canal.findByPk(req.params.id);
  if (!canal) return res.status(404).json({ error: 'Canal não encontrado' });

  await canal.destroy();
  res.status(204).end();
});

export default router;
