export default (sequelize, DataTypes) => {
  return sequelize.define('Filme', {
    titulo: {
      type: DataTypes.STRING,
      allowNull: false
    },
    genero: {
      type: DataTypes.STRING,
      allowNull: false
    },
    ano_lancamento: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    nota_avaliacao: {
      type: DataTypes.FLOAT,
      defaultValue: 0
    }
  }, {
    tableName: 'filmes', // se usar nome de tabela diferente
    timestamps: true,    // cria createdAt / updatedAt
    underscored: true   // usa snake_case
  });
};
