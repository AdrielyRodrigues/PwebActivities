import { Sequelize, DataTypes } from 'sequelize';
import criarUsuario from './Usuario.js';
import criarCanal from './Canal.js';
import criarFilme from './Filme.js';
import criarPlaylist from './Playlist.js';

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: ':memory:'
});

const Usuario = criarUsuario(sequelize, DataTypes);
const Canal = criarCanal(sequelize, DataTypes);
const Filme = criarFilme(sequelize, DataTypes);
const Playlist = criarPlaylist(sequelize, DataTypes);

// Aqui você pode definir relacionamentos se necessário

export {
  sequelize,
  Sequelize,
  Usuario,
  Canal,
  Filme,
  Playlist
};
