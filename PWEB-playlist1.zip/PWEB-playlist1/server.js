import express from 'express';
import { sequelize } from './models/index.js';

import UsuariosRouter from './routes/UsuariosRouter.js';
import CanaisRouter from './routes/CanaisRouter.js';
import FilmesRouter from './routes/FilmesRouter.js';
import PlaylistsRouter from './routes/PlaylistsRouter.js';

const app = express();
const PORT = 3000;

app.use(express.json());

// Registro das rotas
app.use('/usuarios', UsuariosRouter);
app.use('/canais', CanaisRouter);
app.use('/filmes', FilmesRouter);
app.use('/playlists', PlaylistsRouter);

// Teste de conexão com o banco e inicialização do servidor
sequelize.authenticate()
  .then(() => {
    console.log('Conectado ao banco de dados com sucesso!');
    return sequelize.sync(); // sincroniza os modelos (cria tabelas se necessário)
  })
  .then(() => {
    console.log('Database sincronizado com sucesso!');
    app.listen(PORT, () => {
      console.log(`Servidor rodando na porta ${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Erro ao conectar ao banco de dados:', err);
  });
